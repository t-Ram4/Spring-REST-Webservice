package com.annathe.training.springrest3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRest3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
