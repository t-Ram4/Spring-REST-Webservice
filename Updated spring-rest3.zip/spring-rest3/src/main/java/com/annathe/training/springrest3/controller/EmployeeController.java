package com.annathe.training.springrest3.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.annathe.training.springrest3.exception.EmployeeNotFoundException;
import com.annathe.training.springrest3.exception.Error;
import com.annathe.training.springrest3.model.Employee;

@RestController
public class EmployeeController {
	
	@GetMapping("/employees") 
	public List getAllEmployees() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		List employeeList = (ArrayList) context.getBean("employeeList"); 
		
		return employeeList;
		
	}
	

	@GetMapping("/employees/{id}") 
	public Employee getEmployee(@PathVariable int id) throws EmployeeNotFoundException{
		

		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		List employeeList = (ArrayList) context.getBean("employeeList"); 
		
		Employee employee = null;
		Iterator itr = employeeList.iterator();
		
		while(itr.hasNext()) {
			
			 employee = (Employee)itr.next();
			
			if(employee.getId()==id) {
				
				break;
			}
		
			employee = null;
		
		}
		
		if (employee == null) {
			
			throw new EmployeeNotFoundException(id);
		}
		return employee;
		
	}
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND) 
	public Error employeeNotFound(EmployeeNotFoundException e) {
		
		int id = e.getId();
		
		return new Error(id,"Employee not found");
		
		
	}
	
}
