package com.annathe.training.springrest3.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

 
public class EmployeeNotFoundException extends RuntimeException{

	private int id;
	
	public int getId() {
		return id;
	}

	public EmployeeNotFoundException(int id) {
		
		this.id = id;
	}

}
