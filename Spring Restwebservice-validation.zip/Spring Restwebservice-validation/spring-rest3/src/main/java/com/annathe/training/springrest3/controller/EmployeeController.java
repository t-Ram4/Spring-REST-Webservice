package com.annathe.training.springrest3.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.annathe.training.springrest3.exception.EmployeeNotFoundException;
import com.annathe.training.springrest3.exception.Error;
import com.annathe.training.springrest3.model.Employee;

import javax.validation.*;

@RestController
public class EmployeeController {
	
	Map<Integer,Employee> employeeDatabase = new HashMap<Integer,Employee>();
	
	
	public EmployeeController() {
		
		System.out.println("Inside EmployeeController");
	}
	
	@GetMapping("/employees") 
	public List getAllEmployees() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		List employeeList = (ArrayList) context.getBean("employeeList"); 
		
		return employeeList;
		
	}
	

	@GetMapping("/employees/{id}") 
	public Employee getEmployee(@PathVariable int id) throws EmployeeNotFoundException{
		

		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		List employeeList = (ArrayList) context.getBean("employeeList"); 
		
		Employee employee = null;
		Iterator itr = employeeList.iterator();
		
		while(itr.hasNext()) {
			
			 employee = (Employee)itr.next();
			
			if(employee.getId()==id) {
				
				break;
			}
		
			employee = null;
		
		}
		
		if (employee == null) {
			
			throw new EmployeeNotFoundException(id);
		}
		return employee;
		
	}
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND) 
	public Error employeeNotFound(EmployeeNotFoundException e) {
		
		int id = e.getId();
		
		return new Error(id,"Employee not found");
		
		
	}
	
	@PostMapping("/employees")
	 
	public Employee createEmployee(@RequestBody @Valid Employee employee) {	
		
		System.out.println("Start");
				
		
		/*
		 * ValidatorFactory factory =Validation.buildDefaultValidatorFactory();
		 * 
		 * Validator validator = factory.getValidator();
		 * 
		 * System.out.println("Validator: "+validator);
		 * 
		 * Set<ConstraintViolation<Employee>> violations = validator.validate(employee);
		 * 
		 * 
		 * 
		 * List<String> err = new ArrayList<String>();
		 * 
		 * for (ConstraintViolation<Employee> v:violations){
		 * 
		 * err.add(v.getMessage()); }
		 * 
		 * if(violations.size()>0){
		 * 
		 * throw new ResponseStatusException(HttpStatus.BAD_REQUEST,err.toString()); }
		 */
		
		if(employeeDatabase.containsKey(employee.getId())) {
			
			employee.setMessage("Employee already exist");
			
		}
		else {
			
			employeeDatabase.put(employee.getId(), employee);
			employee.setMessage("Employee created");
			
		}
				
		return employee;
		
		
	}
	
}
