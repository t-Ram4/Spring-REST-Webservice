package com.annathe.training.springrest3.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@GetMapping("/employees") 
	public List getAllEmployees() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		List employeeList = (ArrayList) context.getBean("employeeList"); 
		
		return employeeList;
		
	}
	

}
